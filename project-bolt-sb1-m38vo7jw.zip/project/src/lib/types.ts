export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  role: 'admin' | 'editor' | 'author' | 'reader';
  created_at: string;
}

export interface EditorialBoardMember {
  id: string;
  full_name: string;
  role: string;
  affiliation: string | null;
  country: string | null;
  email: string | null;
  bio: string | null;
  expertise: string | null;
  display_order: number;
  created_at: string;
}

export interface Article {
  id: string;
  title: string;
  title_ar: string | null;
  abstract: string | null;
  abstract_ar: string | null;
  authors: string | null;
  keywords: string | null;
  doi: string | null;
  file_url: string | null;
  volume: string | null;
  issue: string | null;
  pages: string | null;
  published_date: string | null;
  status: string;
  created_at: string;
}

export interface Submission {
  id: string;
  title: string;
  authors: string;
  author_email: string;
  abstract: string | null;
  keywords: string | null;
  file_url: string | null;
  file_name: string | null;
  status: string;
  submitted_at: string;
}
