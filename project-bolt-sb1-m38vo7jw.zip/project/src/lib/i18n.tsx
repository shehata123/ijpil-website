import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

export type Lang = 'en' | 'ar';

type Dict = Record<string, { en: string; ar: string }>;

const dict: Dict = {
  // Nav
  'nav.home': { en: 'Home', ar: 'الرئيسية' },
  'nav.about': { en: 'About', ar: 'حول المجلة' },
  'nav.submit': { en: 'Submit', ar: 'تقديم البحث' },
  'nav.editorialBoard': { en: 'Editorial Board', ar: 'هيئة التحرير' },
  'nav.contact': { en: 'Contact', ar: 'اتصل بنا' },

  // Home — hero
  'home.heroTitle': {
    en: 'International Journal of Public International Law',
    ar: 'المجلة الدولية للقانون الدولي العام',
  },
  'home.heroSubtitle': {
    en: 'A peer-reviewed open-access journal dedicated to the advancement of public international law scholarship.',
    ar: 'مجلة محكمة مفتوحة الوصول مكرسة لتقدم البحث في القانون الدولي العام.',
  },
  'home.submitArticle': { en: 'Submit Your Article', ar: 'قدم بحثك' },
  'home.browseArticles': { en: 'Browse Articles', ar: 'تصفح المقالات' },

  // Home — scope
  'home.scopeTitle': { en: 'Journal Scope', ar: 'نطاق المجلة' },
  'home.scopeText': {
    en: 'The journal covers all areas of public international law, including but not limited to: international human rights law, international humanitarian law, international criminal law, international environmental law, international economic law, law of the sea, international organizations, humanitarian studies, social studies, sports law, and all interdisciplinary fields related to public international law.',
    ar: 'تشمل المجلة جميع مجالات القانون الدولي العام، بما في ذلك على سبيل المثال لا الحصر: القانون الدولي لحقوق الإنسان، القانون الدولي الإنساني، القانون الجنائي الدولي، القانون الدولي البيئي، القانون الاقتصادي الدولي، قانون البحار، المنظمات الدولية، الدراسات الإنسانية، الدراسات الاجتماعية، القانون الرياضي، وجميع الفروع الأخرى المتداخلة مع القانون الدولي العام.',
  },

  // Home — latest articles
  'home.latestArticles': { en: 'Latest Articles', ar: 'أحدث المقالات' },
  'home.noArticles': { en: 'No articles published yet', ar: 'لا توجد مقالات منشورة بعد' },
  'home.viewAllArticles': { en: 'View All Articles', ar: 'عرض جميع المقالات' },
  'home.readMore': { en: 'Read More', ar: 'اقرأ المزيد' },

  // About
  'about.title': { en: 'About the Journal', ar: 'حول المجلة' },
  'about.overview': { en: 'Overview', ar: 'نظرة عامة' },
  'about.overviewText': {
    en: 'The International Journal of Public International Law is a peer-reviewed, open-access publication committed to disseminating high-quality scholarly research across all domains of public international law. We welcome original articles, case comments, and book reviews from scholars, practitioners, and researchers worldwide.',
    ar: 'المجلة الدولية للقانون الدولي العام هي منشور محكم ومفتوح الوصول ملتزم بنشر البحوث العلمية عالية الجودة في جميع مجالات القانون الدولي العام. نرحب بالمقالات الأصلية وتعليقات الأحكام ومراجعات الكتب من الباحثين والممارسين والأساتذة من جميع أنحاء العالم.',
  },
  'about.scopeTitle': { en: 'Journal Scope', ar: 'نطاق المجلة' },

  // Submit
  'submit.title': { en: 'Submit Your Manuscript', ar: 'قدم مخطوطتك' },
  'submit.subtitle': {
    en: 'Fill out the form below and upload your manuscript file.',
    ar: 'املأ النموذج أدناه وقم بتحميل ملف مخطوطتك.',
  },
  'submit.manuscriptFile': { en: 'Manuscript File', ar: 'ملف المخطوطة' },
  'submit.uploadHint': { en: 'Click to upload your manuscript', ar: 'انقر لتحميل مخطوطتك' },
  'submit.fileHelper': {
    en: 'PDF, DOC, or DOCX — max 20 MB',
    ar: 'صيغة PDF أو DOC أو DOCX — بحد أقصى 20 ميجابايت',
  },
  'submit.fileTypeError': {
    en: 'Please upload a PDF, DOC, or DOCX file.',
    ar: 'يرجى تحميل ملف بصيغة PDF أو DOC أو DOCX.',
  },
  'submit.fileSizeError': {
    en: 'File size must not exceed 20 MB.',
    ar: 'حجم الملف يجب ألا يتجاوز 20 ميجابايت.',
  },
  'submit.uploadError': { en: 'Failed to upload manuscript.', ar: 'فشل تحميل المخطوطة.' },
  'submit.titleField': { en: 'Article Title', ar: 'عنوان البحث' },
  'submit.authorsField': { en: 'Author(s)', ar: 'المؤلف/المؤلفون' },
  'submit.emailField': { en: 'Corresponding Author Email', ar: 'بريد المؤلف المراسل' },
  'submit.abstractField': { en: 'Abstract', ar: 'الملخص' },
  'submit.keywordsField': { en: 'Keywords', ar: 'الكلمات المفتاحية' },
  'submit.submitBtn': { en: 'Submit Manuscript', ar: 'تقديم المخطوطة' },
  'submit.success': {
    en: 'Your manuscript has been submitted successfully. We will contact you soon.',
    ar: 'تم تقديم مخطوطتك بنجاح. سنتواصل معك قريباً.',
  },
  'submit.error': {
    en: 'An error occurred during submission. Please try again.',
    ar: 'حدث خطأ أثناء التقديم. يرجى المحاولة مرة أخرى.',
  },
  'submit.required': { en: 'This field is required', ar: 'هذا الحقل مطلوب' },

  // Editorial Board
  'editorial.title': { en: 'Editorial Board', ar: 'هيئة التحرير' },
  'editorial.subtitle': {
    en: 'Meet the distinguished scholars behind our journal.',
    ar: 'تعرف على العلماء المتميزين خلف مجلتنا.',
  },
  'editorial.empty': {
    en: 'Editorial board information coming soon',
    ar: 'سيتم الإعلان عن هيئة التحرير قريباً',
  },
  'editorial.expertise': { en: 'Expertise', ar: 'التخصص' },
  'editorial.affiliation': { en: 'Affiliation', ar: 'الانتماء' },
  'editorial.country': { en: 'Country', ar: 'الدولة' },

  // Contact
  'contact.title': { en: 'Contact Us', ar: 'اتصل بنا' },
  'contact.subtitle': {
    en: 'We welcome your inquiries and feedback.',
    ar: 'نرحب باستفساراتك وملاحظاتك.',
  },
  'contact.address': { en: 'Address', ar: 'العنوان' },
  'contact.addressValue': { en: 'Cairo, Egypt', ar: 'القاهرة، مصر' },
  'contact.email': { en: 'Email', ar: 'البريد الإلكتروني' },
  'contact.issn': { en: 'ISSN', ar: 'الرقم الدولي' },
  'contact.issnValue': { en: 'Request Pending', ar: 'قيد الطلب' },

  // Footer
  'footer.about': { en: 'About', ar: 'حول' },
  'footer.aboutText': {
    en: 'A peer-reviewed open-access journal dedicated to public international law.',
    ar: 'مجلة محكمة مفتوحة الوصول مكرسة للقانون الدولي العام.',
  },
  'footer.quickLinks': { en: 'Quick Links', ar: 'روابط سريعة' },
  'footer.contact': { en: 'Contact', ar: 'اتصل بنا' },
  'footer.rights': { en: 'All rights reserved.', ar: 'جميع الحقوق محفوظة.' },
  'footer.issnLabel': { en: 'ISSN', ar: 'الرقم الدولي' },

  // Article
  'article.authors': { en: 'Authors', ar: 'المؤلفون' },
  'article.abstract': { en: 'Abstract', ar: 'الملخص' },
  'article.keywords': { en: 'Keywords', ar: 'الكلمات المفتاحية' },
  'article.download': { en: 'Download PDF', ar: 'تحميل PDF' },
  'article.published': { en: 'Published', ar: 'تاريخ النشر' },
  'article.volume': { en: 'Volume', ar: 'المجلد' },
  'article.issue': { en: 'Issue', ar: 'العدد' },
  'article.back': { en: 'Back to Articles', ar: 'العودة إلى المقالات' },
  'article.notFound': { en: 'Article not found', ar: 'المقال غير موجود' },
};

interface I18nContextType {
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (key: string) => string;
  dir: 'ltr' | 'rtl';
}

const I18nContext = createContext<I18nContextType | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    const stored = typeof localStorage !== 'undefined' ? localStorage.getItem('ijpil-lang') : null;
    return stored === 'ar' ? 'ar' : 'en';
  });

  const setLang = (l: Lang) => {
    setLangState(l);
    if (typeof localStorage !== 'undefined') localStorage.setItem('ijpil-lang', l);
  };

  const dir = lang === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir]);

  const t = (key: string): string => {
    const entry = dict[key];
    if (!entry) return key;
    return entry[lang];
  };

  return (
    <I18nContext.Provider value={{ lang, setLang, t, dir }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}
