export const JOURNAL_NAME_EN = 'International Journal of Public International Law';
export const JOURNAL_NAME_AR = 'المجلة الدولية للقانون الدولي العام';
export const JOURNAL_SHORT = 'IJPIL';

export const CONTACT_EMAIL = 'drshehataoffice@gmail.com';
export const CONTACT_ADDRESS_EN = 'Cairo, Egypt';
export const CONTACT_ADDRESS_AR = 'القاهرة، مصر';
export const ISSN_EN = 'Request Pending';
export const ISSN_AR = 'قيد الطلب';

export const MANUSCRIPT_MAX_SIZE = 20 * 1024 * 1024; // 20 MB

export const ACCEPTED_EXTENSIONS = '.pdf,.doc,.docx';
export const ACCEPTED_MIME_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
export const ACCEPTED_EXTENSIONS_LIST = ['pdf', 'doc', 'docx'];
export const ACCEPT_ATTR =
  '.pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document';
