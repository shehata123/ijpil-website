import { useI18n } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { JOURNAL_SHORT, CONTACT_EMAIL, CONTACT_ADDRESS_EN, CONTACT_ADDRESS_AR, ISSN_EN, ISSN_AR } from '@/lib/constants';
import { Scale, MapPin, Mail, BookOpen } from 'lucide-react';

export default function Footer() {
  const { t, lang } = useI18n();
  const { navigate } = useRouter();

  const quickLinks = [
    { key: 'nav.home', href: '/' },
    { key: 'nav.about', href: '/about' },
    { key: 'nav.submit', href: '/submit' },
    { key: 'nav.editorialBoard', href: '/editorial-board' },
    { key: 'nav.contact', href: '/contact' },
  ];

  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {/* About */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center">
                <Scale className="w-6 h-6 text-amber-400" strokeWidth={1.5} />
              </div>
              <div className="text-base font-bold text-white">{JOURNAL_SHORT}</div>
            </div>
            <p className="text-sm leading-relaxed text-slate-400">
              {t('footer.aboutText')}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">
              {t('footer.quickLinks')}
            </h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => navigate(link.href)}
                    className="text-sm text-slate-400 hover:text-amber-400 transition-colors"
                  >
                    {t(link.key)}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">
              {t('footer.contact')}
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-slate-400">
                  {lang === 'ar' ? CONTACT_ADDRESS_AR : CONTACT_ADDRESS_EN}
                </span>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                <a
                  href={`mailto:${CONTACT_EMAIL}`}
                  className="text-sm text-slate-400 hover:text-amber-400 transition-colors break-all"
                >
                  {CONTACT_EMAIL}
                </a>
              </li>
              <li className="flex items-start gap-2">
                <BookOpen className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-slate-400">
                  {t('footer.issnLabel')}: {lang === 'ar' ? ISSN_AR : ISSN_EN}
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-8 border-t border-slate-800">
          <p className="text-sm text-slate-500 text-center">
            &copy; {new Date().getFullYear()} {JOURNAL_SHORT}. {t('footer.rights')}
          </p>
        </div>
      </div>
    </footer>
  );
}
