import { useI18n } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { JOURNAL_SHORT } from '@/lib/constants';
import { Scale, Menu, X, Globe } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const { t, lang, setLang } = useI18n();
  const { path, navigate } = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { key: 'nav.home', href: '/' },
    { key: 'nav.about', href: '/about' },
    { key: 'nav.submit', href: '/submit' },
    { key: 'nav.editorialBoard', href: '/editorial-board' },
    { key: 'nav.contact', href: '/contact' },
  ];

  const isActive = (href: string) => {
    if (href === '/') return path === '/' || path === '';
    return path.startsWith(href);
  };

  const handleNav = (href: string) => {
    navigate(href);
    setMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <button
            onClick={() => handleNav('/')}
            className="flex items-center gap-3 group"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-slate-800 to-slate-600 rounded-lg flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
              <Scale className="w-6 h-6 md:w-7 md:h-7 text-amber-400" strokeWidth={1.5} />
            </div>
            <div className="text-left">
              <div className="text-sm md:text-base font-bold text-slate-800 leading-tight">
                {JOURNAL_SHORT}
              </div>
              <div className="text-[10px] md:text-xs text-slate-500 leading-tight hidden sm:block">
                {lang === 'ar' ? 'القانون الدولي العام' : 'Public International Law'}
              </div>
            </div>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.href}
                onClick={() => handleNav(item.href)}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                  isActive(item.href)
                    ? 'text-slate-900 bg-slate-100'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                {t(item.key)}
              </button>
            ))}
          </nav>

          {/* Right controls */}
          <div className="flex items-center gap-2">
            {/* Language toggle */}
            <button
              onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
              className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors"
              aria-label="Toggle language"
            >
              <Globe className="w-4 h-4" />
              <span>{lang === 'en' ? 'العربية' : 'English'}</span>
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors"
              aria-label="Menu"
            >
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {menuOpen && (
          <nav className="md:hidden py-3 border-t border-slate-100">
            {navItems.map((item) => (
              <button
                key={item.href}
                onClick={() => handleNav(item.href)}
                className={`block w-full text-start px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                  isActive(item.href)
                    ? 'text-slate-900 bg-slate-100'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                {t(item.key)}
              </button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
