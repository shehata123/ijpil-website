import { I18nProvider, useI18n } from '@/lib/i18n';
import { RouterProvider, useRouter } from '@/lib/router';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import HomePage from '@/pages/HomePage';
import AboutPage from '@/pages/AboutPage';
import SubmitPage from '@/pages/SubmitPage';
import EditorialBoardPage from '@/pages/EditorialBoardPage';
import ContactPage from '@/pages/ContactPage';
import ArticleDetailPage from '@/pages/ArticleDetailPage';

function AppRoutes() {
  const { path } = useRouter();

  const renderPage = () => {
    if (path === '/' || path === '') return <HomePage />;

    if (path === '/about') return <AboutPage />;
    if (path === '/submit') return <SubmitPage />;
    if (path === '/editorial-board') return <EditorialBoardPage />;
    if (path === '/contact') return <ContactPage />;

    // Article detail: /article/:id
    if (path.startsWith('/article/')) {
      const id = path.replace('/article/', '');
      return <ArticleDetailPage id={id} />;
    }

    // Fallback to home
    return <HomePage />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />
      <main className="flex-1">{renderPage()}</main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <I18nProvider>
      <RouterProvider>
        <AppRoutes />
      </RouterProvider>
    </I18nProvider>
  );
}

export default App;
