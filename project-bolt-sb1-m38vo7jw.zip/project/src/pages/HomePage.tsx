import { useI18n } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { supabase } from '@/lib/supabase';
import type { Article } from '@/lib/types';
import { useEffect, useState } from 'react';
import { Scale, FileText, ArrowRight, BookOpen, Send, Globe2, Gavel, Users } from 'lucide-react';

export default function HomePage() {
  const { t, lang, dir } = useI18n();
  const { navigate } = useRouter();
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('articles')
        .select('*')
        .eq('status', 'published')
        .order('published_date', { ascending: false })
        .limit(6);
      setArticles(data || []);
      setLoading(false);
    })();
  }, []);

  const scopeItems = [
    { icon: Users, en: 'Human Rights Law', ar: 'قانون حقوق الإنسان' },
    { icon: Gavel, en: 'International Criminal Law', ar: 'القانون الجنائي الدولي' },
    { icon: Globe2, en: 'International Organizations', ar: 'المنظمات الدولية' },
    { icon: BookOpen, en: 'Law of the Sea', ar: 'قانون البحار' },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-700 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 bg-amber-400 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-400 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/10 backdrop-blur-sm rounded-full text-sm font-medium mb-6 border border-white/20">
              <Scale className="w-4 h-4 text-amber-400" />
              <span>{lang === 'ar' ? 'مجلة محكمة مفتوحة الوصول' : 'Peer-Reviewed Open Access Journal'}</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-bold leading-tight mb-6">
              {t('home.heroTitle')}
            </h1>
            <p className="text-lg md:text-xl text-slate-300 leading-relaxed mb-8">
              {t('home.heroSubtitle')}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => navigate('/submit')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-amber-500 text-slate-900 font-semibold rounded-lg hover:bg-amber-400 transition-colors shadow-lg"
              >
                <Send className="w-5 h-5" />
                {t('home.submitArticle')}
              </button>
              <button
                onClick={() => navigate('#articles')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-white/10 backdrop-blur-sm text-white font-semibold rounded-lg hover:bg-white/20 transition-colors border border-white/20"
              >
                <BookOpen className="w-5 h-5" />
                {t('home.browseArticles')}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Scope Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-800 mb-4">
              {t('home.scopeTitle')}
            </h2>
            <div className="w-20 h-1 bg-amber-500 mx-auto mb-8" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className={`text-base md:text-lg text-slate-600 leading-loose ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                {t('home.scopeText')}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {scopeItems.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div
                    key={idx}
                    className="p-6 bg-slate-50 rounded-xl border border-slate-100 hover:border-amber-200 hover:shadow-md transition-all"
                  >
                    <div className="w-12 h-12 bg-slate-800 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-amber-400" />
                    </div>
                    <p className="text-sm font-semibold text-slate-700">
                      {lang === 'ar' ? item.ar : item.en}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <section id="articles" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-10 gap-4">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-800">
              {t('home.latestArticles')}
            </h2>
            {articles.length > 0 && (
              <button
                onClick={() => navigate('/about')}
                className="inline-flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-amber-600 transition-colors"
              >
                {t('home.viewAllArticles')}
                <ArrowRight className={`w-4 h-4 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
              </button>
            )}
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-xl p-6 border border-slate-100 animate-pulse">
                  <div className="h-4 bg-slate-200 rounded w-1/4 mb-4" />
                  <div className="h-6 bg-slate-200 rounded mb-3" />
                  <div className="h-4 bg-slate-100 rounded mb-2" />
                  <div className="h-4 bg-slate-100 rounded w-3/4" />
                </div>
              ))}
            </div>
          ) : articles.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <FileText className="w-10 h-10 text-slate-400" />
              </div>
              <p className="text-lg text-slate-500 font-medium">
                {t('home.noArticles')}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {articles.map((article) => (
                <article
                  key={article.id}
                  className="bg-white rounded-xl p-6 border border-slate-100 hover:border-amber-200 hover:shadow-lg transition-all cursor-pointer group"
                  onClick={() => navigate(`/article/${article.id}`)}
                >
                  {article.volume && (
                    <span className="inline-block text-xs font-medium text-amber-700 bg-amber-50 px-3 py-1 rounded-full mb-3">
                      {t('article.volume')} {article.volume}
                      {article.issue ? ` · ${t('article.issue')} ${article.issue}` : ''}
                    </span>
                  )}
                  <h3 className="text-lg font-bold text-slate-800 mb-3 group-hover:text-amber-700 transition-colors line-clamp-2">
                    {lang === 'ar' && article.title_ar ? article.title_ar : article.title}
                  </h3>
                  {article.authors && (
                    <p className="text-sm text-slate-500 mb-3">{article.authors}</p>
                  )}
                  {article.abstract && (
                    <p className="text-sm text-slate-600 line-clamp-3 mb-4">
                      {lang === 'ar' && article.abstract_ar ? article.abstract_ar : article.abstract}
                    </p>
                  )}
                  <span className="inline-flex items-center gap-1 text-sm font-medium text-amber-600 group-hover:gap-2 transition-all">
                    {t('home.readMore')}
                    <ArrowRight className={`w-4 h-4 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
                  </span>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
