import { useI18n } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { ArrowRight, Send, BookOpen, Users, Globe2, Gavel, Shield, FileText } from 'lucide-react';

export default function AboutPage() {
  const { t, lang, dir } = useI18n();
  const { navigate } = useRouter();

  const features = [
    {
      icon: Shield,
      en: 'Peer-Reviewed',
      ar: 'محكمة',
      desc_en: 'All articles undergo rigorous double-blind peer review by international experts.',
      desc_ar: 'جميع المقالات تخضع لمراجعة مزدوجة متخفية من قبل خبراء دوليين.',
    },
    {
      icon: Globe2,
      en: 'Open Access',
      ar: 'مفتوحة الوصول',
      desc_en: 'Free and immediate access to all published content for readers worldwide.',
      desc_ar: 'وصول مجاني وفوري لجميع المحتويات المنشورة للقراء في جميع أنحاء العالم.',
    },
    {
      icon: FileText,
      en: 'Bilingual',
      ar: 'ثنائية اللغة',
      desc_en: 'Published in both English and Arabic to serve a global and regional audience.',
      desc_ar: 'تنشر باللغتين الإنجليزية والعربية لخدمة جمهور عالمي وإقليمي.',
    },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-slate-900 to-slate-700 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('about.title')}</h1>
          <div className="w-20 h-1 bg-amber-500" />
        </div>
      </section>

      {/* Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-slate-800 mb-6">{t('about.overview')}</h2>
          <p className={`text-base md:text-lg text-slate-600 leading-loose ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
            {t('about.overviewText')}
          </p>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((f, idx) => {
              const Icon = f.icon;
              return (
                <div key={idx} className="bg-white p-8 rounded-xl border border-slate-100 text-center hover:shadow-lg transition-shadow">
                  <div className="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <Icon className="w-8 h-8 text-amber-400" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-800 mb-3">
                    {lang === 'ar' ? f.ar : f.en}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {lang === 'ar' ? f.desc_ar : f.desc_en}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Scope */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">{t('about.scopeTitle')}</h2>
          <div className="w-20 h-1 bg-amber-500 mb-8" />
          <div className="p-8 bg-slate-50 rounded-xl border border-slate-100">
            <p className={`text-base md:text-lg text-slate-700 leading-loose ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
              {t('home.scopeText')}
            </p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-slate-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            {lang === 'ar' ? 'جاهز للنشر معنا؟' : 'Ready to publish with us?'}
          </h2>
          <p className="text-slate-300 mb-8">
            {lang === 'ar' ? 'قدّم مخطوطتك اليوم وانضم إلى مجتمعنا العلمي.' : 'Submit your manuscript today and join our scholarly community.'}
          </p>
          <button
            onClick={() => navigate('/submit')}
            className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500 text-slate-900 font-semibold rounded-lg hover:bg-amber-400 transition-colors shadow-lg"
          >
            <Send className="w-5 h-5" />
            {t('home.submitArticle')}
          </button>
        </div>
      </section>
    </div>
  );
}
