import { useI18n } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { CONTACT_EMAIL, CONTACT_ADDRESS_EN, CONTACT_ADDRESS_AR, ISSN_EN, ISSN_AR } from '@/lib/constants';
import { MapPin, Mail, BookOpen, Send } from 'lucide-react';

export default function ContactPage() {
  const { t, lang, dir } = useI18n();
  const { navigate } = useRouter();

  const contactItems = [
    {
      icon: MapPin,
      label: t('contact.address'),
      value: lang === 'ar' ? CONTACT_ADDRESS_AR : CONTACT_ADDRESS_EN,
    },
    {
      icon: Mail,
      label: t('contact.email'),
      value: CONTACT_EMAIL,
      href: `mailto:${CONTACT_EMAIL}`,
    },
    {
      icon: BookOpen,
      label: t('contact.issn'),
      value: lang === 'ar' ? ISSN_AR : ISSN_EN,
    },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-slate-900 to-slate-700 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('contact.title')}</h1>
          <p className="text-lg text-slate-300">{t('contact.subtitle')}</p>
          <div className="w-20 h-1 bg-amber-500 mt-6" />
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-20 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            {contactItems.map((item, idx) => {
              const Icon = item.icon;
              const content = (
                <div className="p-8 bg-slate-50 rounded-xl border border-slate-100 hover:border-amber-200 hover:shadow-md transition-all h-full text-center">
                  <div className="w-14 h-14 bg-slate-800 rounded-xl flex items-center justify-center mx-auto mb-5">
                    <Icon className="w-7 h-7 text-amber-400" />
                  </div>
                  <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">
                    {item.label}
                  </h3>
                  <p className="text-base font-medium text-slate-800 break-all">
                    {item.value}
                  </p>
                </div>
              );

              if (item.href) {
                return (
                  <a key={idx} href={item.href} className="block">
                    {content}
                  </a>
                );
              }
              return <div key={idx}>{content}</div>;
            })}
          </div>

          {/* CTA */}
          <div className="p-8 md:p-12 bg-slate-900 rounded-2xl text-center">
            <h2 className="text-xl md:text-2xl font-bold text-white mb-4">
              {lang === 'ar' ? 'لديك مخطوطة للنشر؟' : 'Have a manuscript to publish?'}
            </h2>
            <p className="text-slate-300 mb-8">
              {lang === 'ar' ? 'قدّم بحثك للمراجعة من قبل هيئة التحرير.' : 'Submit your paper for review by our editorial board.'}
            </p>
            <button
              onClick={() => navigate('/submit')}
              className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500 text-slate-900 font-semibold rounded-lg hover:bg-amber-400 transition-colors shadow-lg"
            >
              <Send className="w-5 h-5" />
              {t('home.submitArticle')}
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
