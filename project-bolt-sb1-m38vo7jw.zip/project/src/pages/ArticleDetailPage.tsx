import { useI18n } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { supabase } from '@/lib/supabase';
import type { Article } from '@/lib/types';
import { useEffect, useState } from 'react';
import { ArrowLeft, Download, Calendar, FileText } from 'lucide-react';

export default function ArticleDetailPage({ id }: { id: string }) {
  const { t, lang, dir } = useI18n();
  const { navigate } = useRouter();
  const [article, setArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('articles')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      setArticle(data);
      setLoading(false);
    })();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4">
        <div className="text-center">
          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <FileText className="w-10 h-10 text-slate-400" />
          </div>
          <p className="text-lg text-slate-500 font-medium">{t('article.notFound')}</p>
          <button
            onClick={() => navigate('/')}
            className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 bg-slate-800 text-white font-medium rounded-lg hover:bg-slate-700 transition-colors"
          >
            <ArrowLeft className={`w-4 h-4 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
            {t('article.back')}
          </button>
        </div>
      </div>
    );
  }

  const title = lang === 'ar' && article.title_ar ? article.title_ar : article.title;
  const abstract = lang === 'ar' && article.abstract_ar ? article.abstract_ar : article.abstract;

  return (
    <div className="bg-white min-h-[calc(100vh-200px)]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
        {/* Back */}
        <button
          onClick={() => navigate('/')}
          className={`inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-amber-600 transition-colors mb-8 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
        >
          <ArrowLeft className={`w-4 h-4 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
          {t('article.back')}
        </button>

        {/* Meta */}
        {(article.volume || article.published_date) && (
          <div className="flex flex-wrap items-center gap-4 mb-6 text-sm text-slate-500">
            {article.volume && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-700 font-medium rounded-full text-xs">
                {t('article.volume')} {article.volume}
                {article.issue ? ` · ${t('article.issue')} ${article.issue}` : ''}
              </span>
            )}
            {article.published_date && (
              <span className="inline-flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                {t('article.published')}: {new Date(article.published_date).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
              </span>
            )}
          </div>
        )}

        {/* Title */}
        <h1 className={`text-2xl md:text-3xl font-bold text-slate-800 leading-tight mb-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
          {title}
        </h1>

        {/* Authors */}
        {article.authors && (
          <p className={`text-lg text-slate-600 mb-8 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
            <span className="font-medium text-slate-500">{t('article.authors')}: </span>
            {article.authors}
          </p>
        )}

        {/* Abstract */}
        {abstract && (
          <div className="mb-8 p-6 bg-slate-50 rounded-xl border border-slate-100">
            <h2 className={`text-sm font-bold text-slate-700 uppercase tracking-wider mb-3 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
              {t('article.abstract')}
            </h2>
            <p className={`text-base text-slate-600 leading-loose ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
              {abstract}
            </p>
          </div>
        )}

        {/* Keywords */}
        {article.keywords && (
          <div className="mb-8">
            <h3 className={`text-sm font-semibold text-slate-500 mb-3 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
              {t('article.keywords')}
            </h3>
            <div className="flex flex-wrap gap-2">
              {article.keywords.split(',').map((kw, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 text-sm bg-slate-100 text-slate-600 rounded-full"
                >
                  {kw.trim()}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* DOI */}
        {article.doi && (
          <div className={`mb-8 text-sm ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
            <span className="font-medium text-slate-500">DOI: </span>
            <a
              href={`https://doi.org/${article.doi}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-amber-600 hover:underline"
            >
              {article.doi}
            </a>
          </div>
        )}

        {/* Download */}
        {article.file_url && (
          <div className="pt-6 border-t border-slate-100">
            <a
              href={article.file_url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-slate-800 text-white font-semibold rounded-lg hover:bg-slate-700 transition-colors shadow-md"
            >
              <Download className="w-5 h-5" />
              {t('article.download')}
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
