import { useI18n } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';
import type { EditorialBoardMember } from '@/lib/types';
import { useEffect, useState } from 'react';
import { Users, Mail, Building2, MapPin, Award } from 'lucide-react';

export default function EditorialBoardPage() {
  const { t, lang, dir } = useI18n();
  const [members, setMembers] = useState<EditorialBoardMember[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('editorial_board')
        .select('*')
        .order('display_order', { ascending: true });
      setMembers(data || []);
      setLoading(false);
    })();
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-slate-900 to-slate-700 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('editorial.title')}</h1>
          <p className="text-lg text-slate-300">{t('editorial.subtitle')}</p>
          <div className="w-20 h-1 bg-amber-500 mt-6" />
        </div>
      </section>

      {/* Board Members */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-xl p-6 border border-slate-100 animate-pulse">
                  <div className="w-20 h-20 bg-slate-200 rounded-full mx-auto mb-4" />
                  <div className="h-5 bg-slate-200 rounded mx-auto mb-2 w-2/3" />
                  <div className="h-4 bg-slate-100 rounded mx-auto w-1/2" />
                </div>
              ))}
            </div>
          ) : members.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="w-10 h-10 text-slate-400" />
              </div>
              <p className="text-lg text-slate-500 font-medium">
                {t('editorial.empty')}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {members.map((member) => (
                <div
                  key={member.id}
                  className="bg-white rounded-xl p-8 border border-slate-100 hover:shadow-lg transition-shadow text-center"
                >
                  {/* Avatar */}
                  <div className="w-24 h-24 bg-gradient-to-br from-slate-700 to-slate-900 rounded-full flex items-center justify-center mx-auto mb-5 shadow-md">
                    <span className="text-2xl font-bold text-amber-400">
                      {member.full_name.charAt(0)}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-800 mb-1">
                    {member.full_name}
                  </h3>
                  <p className="text-sm font-medium text-amber-700 mb-4">
                    {member.role}
                  </p>

                  {member.bio && (
                    <p className={`text-sm text-slate-600 leading-relaxed mb-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                      {member.bio}
                    </p>
                  )}

                  <div className={`space-y-2 text-sm text-slate-500 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    {member.affiliation && (
                      <div className="flex items-center gap-2 justify-center">
                        <Building2 className="w-4 h-4 text-slate-400 flex-shrink-0" />
                        <span>{member.affiliation}</span>
                      </div>
                    )}
                    {member.country && (
                      <div className="flex items-center gap-2 justify-center">
                        <MapPin className="w-4 h-4 text-slate-400 flex-shrink-0" />
                        <span>{lang === 'ar' && member.country === 'Egypt' ? 'مصر' : member.country}</span>
                      </div>
                    )}
                    {member.expertise && (
                      <div className="flex items-center gap-2 justify-center">
                        <Award className="w-4 h-4 text-slate-400 flex-shrink-0" />
                        <span>{member.expertise}</span>
                      </div>
                    )}
                    {member.email && (
                      <div className="flex items-center gap-2 justify-center">
                        <Mail className="w-4 h-4 text-slate-400 flex-shrink-0" />
                        <a
                          href={`mailto:${member.email}`}
                          className="text-slate-500 hover:text-amber-600 transition-colors break-all"
                        >
                          {member.email}
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
