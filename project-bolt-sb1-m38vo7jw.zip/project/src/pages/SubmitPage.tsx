import { useI18n } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';
import {
  MANUSCRIPT_MAX_SIZE,
  ACCEPTED_EXTENSIONS_LIST,
  ACCEPT_ATTR,
} from '@/lib/constants';
import { useState, useRef, type ChangeEvent, type FormEvent } from 'react';
import {
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Send,
  X,
} from 'lucide-react';

interface FormState {
  title: string;
  authors: string;
  author_email: string;
  abstract: string;
  keywords: string;
}

const initialState: FormState = {
  title: '',
  authors: '',
  author_email: '',
  abstract: '',
  keywords: '',
};

export default function SubmitPage() {
  const { t, dir } = useI18n();
  const [form, setForm] = useState<FormState>(initialState);
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string>('');
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (f: File): string => {
    const ext = f.name.split('.').pop()?.toLowerCase() || '';
    const validExt = ACCEPTED_EXTENSIONS_LIST.includes(ext);
    const validMime =
      f.type === 'application/pdf' ||
      f.type === 'application/msword' ||
      f.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
      f.type === ''; // Some browsers don't set MIME for .doc/.docx

    if (!validExt || !validMime) {
      return t('submit.fileTypeError');
    }
    if (f.size > MANUSCRIPT_MAX_SIZE) {
      return t('submit.fileSizeError');
    }
    return '';
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const err = validateFile(f);
    if (err) {
      setFileError(err);
      setFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    setFileError('');
    setFile(f);
  };

  const handleRemoveFile = () => {
    setFile(null);
    setFileError('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleChange = (field: keyof FormState, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (fieldErrors[field]) {
      setFieldErrors((prev) => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');

    // Validate required fields
    const errors: Partial<Record<keyof FormState, string>> = {};
    if (!form.title.trim()) errors.title = t('submit.required');
    if (!form.authors.trim()) errors.authors = t('submit.required');
    if (!form.author_email.trim()) errors.author_email = t('submit.required');
    if (!file) errors.title = errors.title || ''; // file is separate
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      if (!file) setFileError(t('submit.required'));
      return;
    }

    setSubmitting(true);

    const selectedFile = file;
    if (!selectedFile) return;

    try {
      // Upload file to storage
      setUploading(true);
      const fileExt = selectedFile.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${fileExt}`;
      const filePath = `submissions/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('manuscripts')
        .upload(filePath, selectedFile);

      setUploading(false);

      if (uploadError) {
        setError(t('submit.uploadError'));
        setSubmitting(false);
        return;
      }

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('manuscripts')
        .getPublicUrl(filePath);

      // Insert submission record
      const { error: insertError } = await supabase.from('submissions').insert({
        title: form.title.trim(),
        authors: form.authors.trim(),
        author_email: form.author_email.trim(),
        abstract: form.abstract.trim() || null,
        keywords: form.keywords.trim() || null,
        file_url: urlData.publicUrl,
        file_name: selectedFile.name,
        status: 'pending',
      });

      if (insertError) {
        setError(t('submit.error'));
        setSubmitting(false);
        return;
      }

      setSuccess(true);
      setForm(initialState);
      setFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch {
      setError(t('submit.error'));
      setSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-[calc(100vh-200px)] flex items-center justify-center bg-slate-50 py-20 px-4">
        <div className="max-w-md text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-12 h-12 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-4">
            {t('submit.success')}
          </h2>
          <button
            onClick={() => setSuccess(false)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-slate-800 text-white font-semibold rounded-lg hover:bg-slate-700 transition-colors"
          >
            {dir === 'rtl' ? 'تقديم مخطوطة أخرى' : 'Submit Another Manuscript'}
          </button>
        </div>
      </div>
    );
  }

  const inputClass = `w-full px-4 py-3 bg-white border rounded-lg text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`;

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-slate-900 to-slate-700 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('submit.title')}</h1>
          <p className="text-lg text-slate-300">{t('submit.subtitle')}</p>
          <div className="w-20 h-1 bg-amber-500 mt-6" />
        </div>
      </section>

      {/* Form */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <form
            onSubmit={handleSubmit}
            className="bg-white rounded-2xl p-6 md:p-10 border border-slate-100 shadow-sm"
          >
            {/* Title */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                {t('submit.titleField')} <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={form.title}
                onChange={(e) => handleChange('title', e.target.value)}
                className={`${inputClass} ${fieldErrors.title ? 'border-red-400' : 'border-slate-200'}`}
                placeholder={dir === 'rtl' ? 'أدخل عنوان البحث' : 'Enter article title'}
              />
              {fieldErrors.title && (
                <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {fieldErrors.title}
                </p>
              )}
            </div>

            {/* Authors */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                {t('submit.authorsField')} <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={form.authors}
                onChange={(e) => handleChange('authors', e.target.value)}
                className={`${inputClass} ${fieldErrors.authors ? 'border-red-400' : 'border-slate-200'}`}
                placeholder={dir === 'rtl' ? 'أدخل أسماء المؤلفين' : 'Enter author name(s)'}
              />
              {fieldErrors.authors && (
                <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {fieldErrors.authors}
                </p>
              )}
            </div>

            {/* Email */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                {t('submit.emailField')} <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                value={form.author_email}
                onChange={(e) => handleChange('author_email', e.target.value)}
                className={`${inputClass} ${fieldErrors.author_email ? 'border-red-400' : 'border-slate-200'}`}
                placeholder={dir === 'rtl' ? 'البريد الإلكتروني' : 'author@example.com'}
                dir="ltr"
              />
              {fieldErrors.author_email && (
                <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {fieldErrors.author_email}
                </p>
              )}
            </div>

            {/* Abstract */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                {t('submit.abstractField')}
              </label>
              <textarea
                value={form.abstract}
                onChange={(e) => handleChange('abstract', e.target.value)}
                rows={5}
                className={`${inputClass} border-slate-200 resize-y`}
                placeholder={dir === 'rtl' ? 'أدخل الملخص' : 'Enter abstract'}
              />
            </div>

            {/* Keywords */}
            <div className="mb-8">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                {t('submit.keywordsField')}
              </label>
              <input
                type="text"
                value={form.keywords}
                onChange={(e) => handleChange('keywords', e.target.value)}
                className={`${inputClass} border-slate-200`}
                placeholder={dir === 'rtl' ? 'كلمة1، كلمة2، كلمة3' : 'keyword1, keyword2, keyword3'}
              />
            </div>

            {/* File Upload */}
            <div className="mb-8">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                {t('submit.manuscriptFile')} <span className="text-red-500">*</span>
              </label>

              {!file ? (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className={`w-full border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:border-amber-400 hover:bg-amber-50/50 transition-all ${fileError && fileError !== t('submit.required') ? 'border-red-300' : ''}`}
                >
                  <div className="w-14 h-14 bg-slate-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Upload className="w-7 h-7 text-slate-500" />
                  </div>
                  <p className="text-sm font-medium text-slate-700 mb-1">
                    {t('submit.uploadHint')}
                  </p>
                  <p className="text-xs text-slate-400">
                    {t('submit.fileHelper')}
                  </p>
                </button>
              ) : (
                <div className="flex items-center gap-4 p-4 bg-slate-50 border border-slate-200 rounded-xl">
                  <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <FileText className="w-6 h-6 text-amber-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-800 truncate">
                      {file.name}
                    </p>
                    <p className="text-xs text-slate-500">
                      {(file.size / (1024 * 1024)).toFixed(2)} MB
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleRemoveFile}
                    className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                    aria-label="Remove file"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept={ACCEPT_ATTR}
                onChange={handleFileChange}
                className="hidden"
              />

              {fileError && fileError !== t('submit.required') && (
                <p className="mt-2 text-sm text-red-500 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {fileError}
                </p>
              )}
              <p className="mt-2 text-xs text-slate-400">
                {t('submit.fileHelper')}
              </p>
            </div>

            {/* Error */}
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={submitting || uploading}
              className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-slate-800 text-white font-semibold rounded-lg hover:bg-slate-700 transition-colors shadow-md disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {submitting || uploading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {uploading
                    ? dir === 'rtl' ? 'جاري التحميل...' : 'Uploading...'
                    : dir === 'rtl' ? 'جاري التقديم...' : 'Submitting...'}
                </>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  {t('submit.submitBtn')}
                </>
              )}
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}
