/*
# Create Journal Schema — International Law Journal

## Overview
Creates the complete database schema for a bilingual (English/Arabic) academic journal
covering public international law. Includes user profiles, editorial board, articles,
and manuscript submissions.

## New Tables

### profiles
- Extends auth.users with application-specific data.
- `id` (uuid, PK, references auth.users)
- `email` (text, unique)
- `full_name` (text)
- `role` (text: 'admin', 'editor', 'author', 'reader' — default 'reader')
- `created_at` (timestamptz)

### editorial_board
- Members of the journal's editorial board.
- `id` (uuid, PK)
- `full_name` (text, not null)
- `role` (text — e.g. 'Founder & Editor-in-Chief')
- `affiliation` (text)
- `country` (text)
- `email` (text)
- `bio` (text)
- `expertise` (text)
- `display_order` (int, default 0)
- `created_at` (timestamptz)

### articles
- Published articles in the journal.
- `id` (uuid, PK)
- `title` (text, not null)
- `title_ar` (text — Arabic title)
- `abstract` (text)
- `abstract_ar` (text — Arabic abstract)
- `authors` (text)
- `keywords` (text)
- `doi` (text, unique)
- `file_url` (text — link to PDF)
- `volume` (text)
- `issue` (text)
- `pages` (text)
- `published_date` (date)
- `status` (text: 'published', 'forthcoming' — default 'published')
- `created_at` (timestamptz)

### submissions
- Manuscript submissions from authors.
- `id` (uuid, PK)
- `title` (text, not null)
- `authors` (text, not null)
- `author_email` (text, not null)
- `abstract` (text)
- `keywords` (text)
- `file_url` (text — link to uploaded manuscript in storage)
- `file_name` (text — original file name)
- `status` (text: 'pending', 'under_review', 'accepted', 'rejected' — default 'pending')
- `submitted_at` (timestamptz)

## Security
- RLS enabled on all tables.
- profiles: owner-scoped (authenticated users manage their own profile).
- editorial_board: public read (anon + authenticated), no public writes.
- articles: public read, admin-only writes (via authenticated with admin role check).
- submissions: public insert (anyone can submit), authenticated read for admins.
- Storage bucket 'manuscripts' created for file uploads, public read, authenticated upload.

## Data Insertions
- Inserts Dr. Mohamed Shehata as Founder & Editor-in-Chief in editorial_board.
- Creates auth user for drshehataoffice@gmail.com and sets profile role to 'admin'.
*/

-- ============================================================
-- PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text,
  role text NOT NULL DEFAULT 'reader',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Allow anyone to read profiles (for editorial board display etc.)
DROP POLICY IF EXISTS "profiles_public_read" ON profiles;
CREATE POLICY "profiles_public_read" ON profiles FOR SELECT
  TO anon, authenticated USING (true);

-- ============================================================
-- EDITORIAL BOARD TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS editorial_board (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  role text NOT NULL,
  affiliation text,
  country text,
  email text,
  bio text,
  expertise text,
  display_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE editorial_board ENABLE ROW LEVEL SECURITY;

-- Public can read editorial board
DROP POLICY IF EXISTS "editorial_board_public_read" ON editorial_board;
CREATE POLICY "editorial_board_public_read" ON editorial_board FOR SELECT
  TO anon, authenticated USING (true);

-- Only admins can insert/update/delete
DROP POLICY IF EXISTS "editorial_board_admin_insert" ON editorial_board;
CREATE POLICY "editorial_board_admin_insert" ON editorial_board FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  );

DROP POLICY IF EXISTS "editorial_board_admin_update" ON editorial_board;
CREATE POLICY "editorial_board_admin_update" ON editorial_board FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  );

DROP POLICY IF EXISTS "editorial_board_admin_delete" ON editorial_board;
CREATE POLICY "editorial_board_admin_delete" ON editorial_board FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  );

-- ============================================================
-- ARTICLES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  title_ar text,
  abstract text,
  abstract_ar text,
  authors text,
  keywords text,
  doi text UNIQUE,
  file_url text,
  volume text,
  issue text,
  pages text,
  published_date date,
  status text NOT NULL DEFAULT 'published',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE articles ENABLE ROW LEVEL SECURITY;

-- Public can read published articles
DROP POLICY IF EXISTS "articles_public_read" ON articles;
CREATE POLICY "articles_public_read" ON articles FOR SELECT
  TO anon, authenticated USING (true);

-- Admin can manage articles
DROP POLICY IF EXISTS "articles_admin_insert" ON articles;
CREATE POLICY "articles_admin_insert" ON articles FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  );

DROP POLICY IF EXISTS "articles_admin_update" ON articles;
CREATE POLICY "articles_admin_update" ON articles FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  );

DROP POLICY IF EXISTS "articles_admin_delete" ON articles;
CREATE POLICY "articles_admin_delete" ON articles FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  );

-- ============================================================
-- SUBMISSIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  authors text NOT NULL,
  author_email text NOT NULL,
  abstract text,
  keywords text,
  file_url text,
  file_name text,
  status text NOT NULL DEFAULT 'pending',
  submitted_at timestamptz DEFAULT now()
);

ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

-- Anyone can submit (insert) — no auth required
DROP POLICY IF EXISTS "submissions_public_insert" ON submissions;
CREATE POLICY "submissions_public_insert" ON submissions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- Admins can read submissions
DROP POLICY IF EXISTS "submissions_admin_read" ON submissions;
CREATE POLICY "submissions_admin_read" ON submissions FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  );

-- Admins can update submission status
DROP POLICY IF EXISTS "submissions_admin_update" ON submissions;
CREATE POLICY "submissions_admin_update" ON submissions FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
  );

-- ============================================================
-- STORAGE BUCKET FOR MANUSCRIPTS
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('manuscripts', 'manuscripts', true)
ON CONFLICT (id) DO NOTHING;

-- Public can read files in manuscripts bucket
DROP POLICY IF EXISTS "manuscripts_public_read" ON storage.objects;
CREATE POLICY "manuscripts_public_read" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'manuscripts');

-- Anyone can upload to manuscripts bucket
DROP POLICY IF EXISTS "manuscripts_public_upload" ON storage.objects;
CREATE POLICY "manuscripts_public_upload" ON storage.objects FOR INSERT
  TO anon, authenticated WITH CHECK (bucket_id = 'manuscripts');

-- ============================================================
-- CREATE AUTH USER FOR DR. SHEHATA
-- ============================================================
DO $$
DECLARE
  new_user_id uuid;
BEGIN
  -- Check if user already exists
  SELECT id INTO new_user_id FROM auth.users WHERE email = 'drshehataoffice@gmail.com';

  IF new_user_id IS NULL THEN
    -- Create auth user
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      last_sign_in_at,
      raw_app_meta_data,
      raw_user_meta_data,
      confirmation_token,
      recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'drshehataoffice@gmail.com',
      crypt('Shehata2026!', gen_salt('bf')),
      now(),
      now(),
      now(),
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"full_name":"Dr. Mohamed Shehata"}'::jsonb,
      '',
      ''
    )
    RETURNING id INTO new_user_id;
  END IF;

  -- Create or update profile with admin role
  INSERT INTO profiles (id, email, full_name, role)
  VALUES (new_user_id, 'drshehataoffice@gmail.com', 'Dr. Mohamed Shehata', 'admin')
  ON CONFLICT (id) DO UPDATE SET role = 'admin', full_name = 'Dr. Mohamed Shehata';
END $$;

-- ============================================================
-- INSERT DR. SHEHATA INTO EDITORIAL BOARD
-- ============================================================
INSERT INTO editorial_board (full_name, role, affiliation, country, email, display_order)
VALUES ('Dr. Mohamed Shehata', 'Founder & Editor-in-Chief', 'Independent Researcher', 'Egypt', 'drshehataoffice@gmail.com', 1)
ON CONFLICT DO NOTHING;

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_articles_published_date ON articles(published_date DESC);
CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_editorial_board_display_order ON editorial_board(display_order);
CREATE INDEX IF NOT EXISTS idx_submissions_status ON submissions(status);
CREATE INDEX IF NOT EXISTS idx_submissions_submitted_at ON submissions(submitted_at DESC);
